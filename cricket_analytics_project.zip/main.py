
from src.analyzer import CricketAnalyzer

def main():
    analyzer = CricketAnalyzer("data/sample_cricket_data.csv")

    player, runs = analyzer.top_scorer()
    print("Top scorer:", player, "-", runs)

    print("Average runs:", analyzer.average_runs())

    print("Strike rate of Virat Kohli:", analyzer.strike_rate("Virat Kohli"))

    analyzer.plot_runs()

if __name__ == "__main__":
    main()
