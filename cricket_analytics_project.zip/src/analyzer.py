
import pandas as pd
import matplotlib.pyplot as plt

class CricketAnalyzer:
    def __init__(self, file_path):
        self.df = pd.read_csv(file_path)

    def top_scorer(self):
        top = self.df.loc[self.df["runs"].idxmax()]
        return top["player"], top["runs"]

    def average_runs(self):
        return self.df["runs"].mean()

    def strike_rate(self, player):
        p = self.df[self.df["player"] == player]
        if len(p) == 0:
            return None
        runs = p["runs"].values[0]
        balls = p["balls"].values[0]
        return round((runs / balls) * 100, 2)

    def plot_runs(self):
        plt.figure()
        plt.bar(self.df["player"], self.df["runs"])
        plt.title("Runs scored by players")
        plt.xticks(rotation=45)
        plt.show()
