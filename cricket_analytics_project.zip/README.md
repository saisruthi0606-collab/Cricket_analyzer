
# Cricket Performance Analyzer

This is a small personal project I built to explore cricket statistics using Python. 
I wanted something simple that could read match data and tell useful insights like:

- Who scored the most runs
- Average runs across players
- Strike rate calculation
- Simple visualization of runs

The idea was to simulate basic cricket analytics like commentators or analysts do.

## Why I made this
As a cricket fan and someone learning Python, I thought this would be a good way to combine both. 
It helped me practice working with CSV files, pandas, and plotting graphs.

## How to run

Install requirements:

pip install pandas matplotlib

Run:

python main.py

## Project structure

data/ → contains cricket dataset  
src/ → contains analyzer logic  
main.py → runs the analysis  

## Future improvements

- Add bowling statistics
- Player comparison
- IPL dataset support
- Web dashboard

This project is beginner friendly and easy to extend.
